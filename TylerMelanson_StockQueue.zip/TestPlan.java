/*
Tyler Melanson - Queues Assignment Test Plan
(PDF wasn't working so I'll put it here)

Key:
+ Buy
- Sell
* Gain
= Remaining

+Bought 28 shares at $30.00 (Day “1”)
+Bought 25 shares at $25.55 (Day “2”)
+Bought 100 shares at $10.12 (Day “3”)
+Bought 82 shares at $11.88 (Day “4”)
+Bought 10 shares at $20.01 (Day “5”)

-Sold 211 shares at $35 (Day “6”)

*All 28 shares from Day 1’s transactions, for a gain of ($35 - $30) * 28 = $140
*All 25 shares from Day 2’s transactions, for a gain of ($35 - $25.55) * 25 = $236.25
*All 100 shares from Day 3’s transactions, for a gain of ($35 - $10.12) * 100 = $2488
*58 of the 82 shares from Day 4’s transactions for a gain of ($35 - $11.88) * 58 = $1340.96

=24 shares at $11.88 remain from Day “4”
=10 shares at $20.01 remain from Day “5”

+Bought 5 shares at $12.00 (Day “7”)
+Bought 8 shares at $5.00 (Day “8”)
+Bought 1 share at $40.40 (Day “9”)

-Sold 40 shares at $22.99 (Day “10”)

*All 24 shares from Day 4’s transactions, for a gain of ($22.99 - $11.88) * 24 = $266.64
*All 10 shares from Day 5’s transactions, for a gain of ($22.99 - $20.01) * 10 = $29.80
*All 5 shares from Day 7’s transactions, for a gain of ($22.99 - $12.00) * 5 = $54.95
*1 of the 8 shares from Day 8’s transactions, for a gain of ($22.99 - $5.00) * 1 = $17.99

=7 shares at $5.00 remain from Day “8”
=1 share at $40.40 remain from Day “9”

+Bought 18 shares at $32.50 (Day “11”)

-Sold 25 shares at $14.00 (Day “12”)

*All 7 shares from Day 8’s transactions, for a gain of ($14.00 - $5.00) * 7 = $63.00
*All 1 share from Day 9’s transactions, for a gain of ($14.00 - $40.40) * 1 = $-26.40
*17 of the 18 shares from Day 11’s transactions, for a gain of ($14.00 - $32.50) * 17 = $-314.50

=1 share at $32.50 remain from Day “11”

+Bought 55 shares at $8.00 (Day “13”)
+Bought 66 shares at $12.75 (Day “14”)

-Sold 70 shares at $20.00 (Day “15”)

*All 1 share from Day 11’s transactions, for a gain of ($20.00 - $32.50) * 1 = $-12.50
*All 55 shares from Day 13’s transactions, for a gain of ($20.00 - $8.00) * 55 = $660
*14 of the 66 shares from Day 14’s transactions, for a gain of ($20.00 - $12.75) * 14 = $101.50

=52 shares at $12.75 remain from Day “14”

+Bought 35 shares at $16.00 (Day “16”)
+Bought 40 shares at $25.00 (Day “17”)

-Sold 66 shares at $28.50 (Day “18”)

*All 52 shares from Day 14’s transactions, for a gain of ($28.50 - $12.75) * 52 = $819.00
*14 of the 35 shares from Day 16’s transactions, for a gain of ($28.50 - $16.00) * 14 = $175.00

=21 shares at $16.00 remain from Day “16”
=40 shares at $25.00 remain from Day “17”

+Bought 10 shares at $100.00 (Day “19”)

-Sold 70 shares at $32.00 (Day “20”)

*All 21 shares from Day 16’s transactions, for a gain of ($32.00 - $16.00) * 21 = $336.00
*All 40 shares from Day 17’s transactions, for a gain of ($32.00 - $25.00) * 40 = $280.00
*9 of the 10 shares from Day 19’s transactions, for a gain of ($32.00 - $100.00) * 9 = $-612.00

=1 share at $100.00 remains from Day “19”

Total Realized Capital Gain: $6043.69
*/
public class TestPlan
{
   
}
